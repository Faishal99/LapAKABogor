# LapAKABogor Store

Website toko online satu halaman untuk memfasilitasi perdagangan UKM & IKM Mahasiswa Politeknik AKA Bogor.

## Fitur:
- Katalog produk berdasarkan kategori
- Checkout otomatis via WhatsApp
- Pilihan ambil sendiri / diantar
- Metode pembayaran: QRIS atau Cash
- Carousel promo produk
- Tampilan warna dominan merah, biru, hijau, oranye

## Cara Akses:
Buka: [https://faishal99.github.io/LapAKABogor/](https://faishal99.github.io/LapAKABogor/)
